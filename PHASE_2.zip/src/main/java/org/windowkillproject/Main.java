package org.windowkillproject;

import org.windowkillproject.application.Application;

public class Main {
    public static void main(String[] args) {
        new Application().run();
    }
}