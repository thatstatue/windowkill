package org.windowkillproject.controller;

import org.windowkillproject.application.panels.game.GamePanel;

public record GamePanelCorner(GamePanel gamePanel, int corner) {
}
