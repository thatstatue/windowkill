package org.windowkillproject.model;

public interface Drawable {
    int getX();

    int getY();
}
