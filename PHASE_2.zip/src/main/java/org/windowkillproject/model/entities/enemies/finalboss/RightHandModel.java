package org.windowkillproject.model.entities.enemies.finalboss;

import org.windowkillproject.application.panels.game.GamePanel;

public class RightHandModel extends HandModel{
    protected RightHandModel( int x, int y) {
        super(x, y);
    }
}
