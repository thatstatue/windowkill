package org.windowkillproject.model.entities;

public interface Circular {
    int getRadius();
}
