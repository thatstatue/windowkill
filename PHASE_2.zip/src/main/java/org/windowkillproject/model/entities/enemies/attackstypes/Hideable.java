package org.windowkillproject.model.entities.enemies.attackstypes;

public interface Hideable {
    void setVisible(boolean visible);
    boolean isVisible();
}
