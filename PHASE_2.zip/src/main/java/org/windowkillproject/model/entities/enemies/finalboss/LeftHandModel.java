package org.windowkillproject.model.entities.enemies.finalboss;

public class LeftHandModel extends HandModel{
    protected LeftHandModel( int x, int y) {
        super( x, y);
    }
}
