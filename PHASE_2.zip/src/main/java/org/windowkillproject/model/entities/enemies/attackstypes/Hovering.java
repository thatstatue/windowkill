package org.windowkillproject.model.entities.enemies.attackstypes;

public interface Hovering {
}
