package org.windowkillproject.application.panels.game;

public enum PanelStatus {
    isometric, shrinkable
}
