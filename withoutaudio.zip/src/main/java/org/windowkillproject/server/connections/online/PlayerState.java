package org.windowkillproject.server.connections.online;

public enum PlayerState {
    online, offline, busy
}
