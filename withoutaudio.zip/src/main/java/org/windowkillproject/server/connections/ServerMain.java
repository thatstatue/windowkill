package org.windowkillproject.server.connections;

public class ServerMain {
    public static void main(String[] args) {
        new GameServer().run();
    }
}
