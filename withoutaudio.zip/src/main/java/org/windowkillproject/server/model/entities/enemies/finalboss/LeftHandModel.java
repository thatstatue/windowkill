package org.windowkillproject.server.model.entities.enemies.finalboss;

import org.windowkillproject.server.model.globe.GlobeModel;

public class LeftHandModel extends HandModel{
    protected LeftHandModel(String globeId, int x, int y) {
        super(globeId, x, y);
    }
}
