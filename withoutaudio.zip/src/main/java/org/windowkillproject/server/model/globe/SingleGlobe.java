package org.windowkillproject.server.model.globe;

import org.windowkillproject.server.model.entities.EpsilonModel;

public class SingleGlobe extends GlobeModel{
    public SingleGlobe(String id, EpsilonModel epsilon1) {
        super(id, epsilon1);
    }
}
