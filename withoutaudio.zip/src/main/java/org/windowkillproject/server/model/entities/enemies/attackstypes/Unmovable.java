package org.windowkillproject.server.model.entities.enemies.attackstypes;

public interface Unmovable {
}
