package org.windowkillproject.server.model.entities.enemies.attackstypes;

public interface Dashable {
    void dash();
    void setCollision(boolean collision);

}
