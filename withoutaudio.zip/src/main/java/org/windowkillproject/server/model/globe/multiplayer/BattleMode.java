package org.windowkillproject.server.model.globe.multiplayer;

public enum BattleMode {
    monomachia, colosseum
}
