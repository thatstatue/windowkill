package org.windowkillproject.server.model.entities.enemies.attackstypes;

public interface Hideable {
    void setVisible(boolean visible);
    boolean isVisible();
}
