package org.windowkillproject.server.model.panelmodels;

public enum PanelStatus {
    isometric, shrinkable
}
