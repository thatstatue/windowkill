package org.windowkillproject.server.model.globe.multiplayer;

import org.windowkillproject.server.model.entities.EpsilonModel;

public class ColosseumGlobe extends MultiGlobe {
    public ColosseumGlobe(String id, EpsilonModel epsilon1, EpsilonModel epsilon2) {
        super( id, epsilon1, epsilon2);
    }
}
