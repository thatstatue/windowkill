package org.windowkillproject.server.model.abilities;

public interface Projectable {
    void shoot();
    void move() ;
    int getX();
    int getY();

    }
