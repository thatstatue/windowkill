package org.windowkillproject.server.model.entities;

public interface Circular {
    int getRadius();
}
