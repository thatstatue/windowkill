package org.windowkillproject.controller;

import org.windowkillproject.server.model.panelmodels.PanelModel;

public record GamePanelCorner(PanelModel panelModel, int corner) {
}
