package org.windowkillproject.client;

public class ClientMain {
    public static void main(String[] args) {
        new GameClient().run();
    }
}
