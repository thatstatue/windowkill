package org.windowkillproject.client.ui.panels.league;

import org.windowkillproject.client.GameClient;
import org.windowkillproject.client.ui.panels.Panel;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import static org.windowkillproject.Constants.*;
import static org.windowkillproject.Request.*;

public class LeaguePanel extends Panel {
    private DefaultTableModel tableModel;
    private JScrollPane scrollPane;
    private KnownSquadPanel mySquad, opponentSquad;
    public LeaguePanel(GameClient client) {
        super(client);
//        client.sendMessage(LEAGUE_REDIRECT + REGEX_SPLIT+REQ_SQUADS_LIST);

        setBackground(Color.decode("#d3ab97"));
        setPreferredSize(new Dimension(APP_WIDTH, APP_HEIGHT));

        scrollPane = new JScrollPane(createItemTable());
        scrollPane.setBounds(50, 100, 300, 300);

        add(scrollPane);
        ActionListener actionListener = e -> {
            client.sendMessage(LEAGUE_REDIRECT+
                    REGEX_SPLIT+ REQ_NEW_SQUAD+
                    REGEX_SPLIT+ client.getUsername()
                    + REGEX_SPLIT+ client.getUsername()+"Squad");
        };
        add(buttonMaker("CREATE" , 790, 100, actionListener));
//        mySquad = new KnownSquadPanel(client, null ,false);
//        opponentSquad = new KnownSquadPanel(client, null, true);
    }
    private ArrayList<String> squadNames = new ArrayList<>();
    private ArrayList<String> occupants = new ArrayList<>();

    public void setOccupants(String[] occupants){
        for (int i = 1; i< occupants.length;i++){
            this.occupants.add(occupants[i]);
        }
        renew();
    }

    public void setSquadNames(String[] squadNames){
        for (int i = 1; i< squadNames.length;i++){
            this.squadNames.add(squadNames[i]);
        }

    }
    @Override
    protected ArrayList<Component> initComponents() {
        ArrayList<Component> componentArrayList = new ArrayList<>();

        JLabel name = jLabelMaker("LEAGUE", 50, 20, 200, 50);
        name.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 35));
        name.setForeground(BUTTON_BG_COLOR);
        componentArrayList.add(name);

        componentArrayList.add(buttonMaker("Menu", 790, 20, e -> client.getApp().initPFrame()));

        return componentArrayList;
    }
    private JTable createItemTable() {
        String[] columnNames = {"Squad Name", "Occupants"};
        tableModel = new DefaultTableModel(columnNames, 0);

        for (int i = 0; i < squadNames.size(); i++) {
            String item = squadNames.get(i);
            String amount = occupants.get(i);
            tableModel.addRow(new Object[]{item, amount});
        }

        JTable table = new JTable(tableModel);
        table.setFillsViewportHeight(true);
        return table;
    }

    public void renew(){
        System.out.println("renew begin at "+ tableModel.getRowCount());
        for (int i = tableModel.getRowCount(); i>0; i--){
            tableModel.removeRow(i-1);
        }

        scrollPane = new JScrollPane(createItemTable());
        scrollPane.revalidate();
        scrollPane.repaint();
        System.out.println("renew end at "+ tableModel.getRowCount());

    }
}